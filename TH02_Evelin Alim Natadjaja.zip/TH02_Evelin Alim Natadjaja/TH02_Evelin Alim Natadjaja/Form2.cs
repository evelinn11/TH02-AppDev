﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02_Evelin_Alim_Natadjaja
{
    public partial class MainTebak : Form
    {
        public string kata;

        public MainTebak(string kataTerpilih)
        {
            InitializeComponent();
            lb_Coba.Text = kataTerpilih;
            kata = kataTerpilih.ToUpper();
        }
        private void CekHuruf(char isi)
        {
            List<string> hurufBenar = new List<string> {lb_Pertama.Text, lb_Kedua.Text,
           lb_Ketiga.Text, lb_Keempat.Text, lb_Kelima.Text};
            int count = 0;

            foreach (char huruf in kata)
            {
                if (huruf == isi)
                {
                    if (count == 0)
                    {
                        lb_Pertama.Text = isi.ToString();
                    }
                    if (count == 1)
                    {
                        lb_Kedua.Text = isi.ToString();
                    }
                    if (count == 2)
                    {
                        lb_Ketiga.Text = isi.ToString();
                    }
                    if (count == 3)
                    {
                        lb_Keempat.Text = isi.ToString();
                    }
                    if (count == 4)
                    {
                        lb_Kelima.Text = isi.ToString();
                    }
                }
                count++;
            }

            if (lb_Pertama.Text + lb_Kedua.Text + lb_Ketiga.Text + lb_Keempat.Text 
                + lb_Kelima.Text == kata)
            {
                MessageBox.Show("You Win");
            }
        }

        private void btn_HurufQ_Click(object sender, EventArgs e)
        {
            CekHuruf('Q');
        }

        private void btn_HurufW_Click(object sender, EventArgs e)
        {
            CekHuruf('W');
        }

        private void btn_HurufE_Click(object sender, EventArgs e)
        {
            CekHuruf('E');
        }

        private void btn_HurufR_Click(object sender, EventArgs e)
        {
            CekHuruf('R');
        }

        private void btn_HurufT_Click(object sender, EventArgs e)
        {
            CekHuruf('T');
        }

        private void btn_HurufY_Click(object sender, EventArgs e)
        {
            CekHuruf('Y');
        }

        private void btn_HurufU_Click(object sender, EventArgs e)
        {
            CekHuruf('U');
        }

        private void btn_HurufI_Click(object sender, EventArgs e)
        {
            CekHuruf('I');
        }

        private void btn_HurufO_Click(object sender, EventArgs e)
        {
            CekHuruf('O');
        }

        private void btn_HurufP_Click(object sender, EventArgs e)
        {
            CekHuruf('P');
        }
        private void btn_HurufA_Click(object sender, EventArgs e)
        {
            CekHuruf('A');
        }

        private void btn_HurufS_Click(object sender, EventArgs e)
        {
            CekHuruf('S');
        }

        private void btn_HurufD_Click(object sender, EventArgs e)
        {
            CekHuruf('D');
        }

        private void btn_HurufF_Click(object sender, EventArgs e)
        {
            CekHuruf('F');
        }

        private void btn_HurufG_Click(object sender, EventArgs e)
        {
            CekHuruf('G');
        }

        private void btn_HurufH_Click(object sender, EventArgs e)
        {
            CekHuruf('H');
        }

        private void btn_HurufJ_Click(object sender, EventArgs e)
        {
            CekHuruf('J');
        }

        private void btn_HurufK_Click(object sender, EventArgs e)
        {
            CekHuruf('K');
        }

        private void btn_HurufL_Click(object sender, EventArgs e)
        {
            CekHuruf('L');
        }

        private void btn_HurufZ_Click(object sender, EventArgs e)
        {
            CekHuruf('Z');
        }

        private void btn_HurufX_Click(object sender, EventArgs e)
        {
            CekHuruf('X');
        }

        private void btn_HurufC_Click(object sender, EventArgs e)
        {
            CekHuruf('C');
        }

        private void btn_HurufV_Click(object sender, EventArgs e)
        {
            CekHuruf('V');
        }

        private void btn_HurufB_Click(object sender, EventArgs e)
        {
            CekHuruf('B');
        }

        private void btn_HurufN_Click(object sender, EventArgs e)
        {
            CekHuruf('N');
        }

        private void btn_HurufM_Click(object sender, EventArgs e)
        {
            CekHuruf('M');
        }
    }
}
