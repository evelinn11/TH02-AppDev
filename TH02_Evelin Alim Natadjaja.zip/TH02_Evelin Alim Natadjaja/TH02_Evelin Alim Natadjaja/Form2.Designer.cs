﻿namespace TH02_Evelin_Alim_Natadjaja
{
    partial class MainTebak
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Coba = new System.Windows.Forms.Label();
            this.lb_Pertama = new System.Windows.Forms.Label();
            this.lb_Keempat = new System.Windows.Forms.Label();
            this.lb_Kelima = new System.Windows.Forms.Label();
            this.lb_Kedua = new System.Windows.Forms.Label();
            this.lb_Ketiga = new System.Windows.Forms.Label();
            this.btn_HurufM = new System.Windows.Forms.Button();
            this.btn_HurufN = new System.Windows.Forms.Button();
            this.btn_HurufB = new System.Windows.Forms.Button();
            this.btn_HurufV = new System.Windows.Forms.Button();
            this.btn_HurufC = new System.Windows.Forms.Button();
            this.btn_HurufX = new System.Windows.Forms.Button();
            this.btn_HurufZ = new System.Windows.Forms.Button();
            this.btn_HurufL = new System.Windows.Forms.Button();
            this.btn_HurufK = new System.Windows.Forms.Button();
            this.btn_HurufJ = new System.Windows.Forms.Button();
            this.btn_HurufH = new System.Windows.Forms.Button();
            this.btn_HurufG = new System.Windows.Forms.Button();
            this.btn_HurufF = new System.Windows.Forms.Button();
            this.btn_HurufD = new System.Windows.Forms.Button();
            this.btn_HurufS = new System.Windows.Forms.Button();
            this.btn_HurufA = new System.Windows.Forms.Button();
            this.btn_HurufP = new System.Windows.Forms.Button();
            this.btn_HurufO = new System.Windows.Forms.Button();
            this.btn_HurufI = new System.Windows.Forms.Button();
            this.btn_HurufU = new System.Windows.Forms.Button();
            this.btn_HurufY = new System.Windows.Forms.Button();
            this.btn_HurufT = new System.Windows.Forms.Button();
            this.btn_HurufR = new System.Windows.Forms.Button();
            this.btn_HurufE = new System.Windows.Forms.Button();
            this.btn_HurufW = new System.Windows.Forms.Button();
            this.btn_HurufQ = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_Coba
            // 
            this.lb_Coba.AutoSize = true;
            this.lb_Coba.Location = new System.Drawing.Point(652, 143);
            this.lb_Coba.Name = "lb_Coba";
            this.lb_Coba.Size = new System.Drawing.Size(28, 13);
            this.lb_Coba.TabIndex = 63;
            this.lb_Coba.Text = "kata";
            // 
            // lb_Pertama
            // 
            this.lb_Pertama.AutoSize = true;
            this.lb_Pertama.Font = new System.Drawing.Font("Century Gothic", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Pertama.Location = new System.Drawing.Point(215, 50);
            this.lb_Pertama.Name = "lb_Pertama";
            this.lb_Pertama.Size = new System.Drawing.Size(65, 77);
            this.lb_Pertama.TabIndex = 62;
            this.lb_Pertama.Text = "_";
            // 
            // lb_Keempat
            // 
            this.lb_Keempat.AutoSize = true;
            this.lb_Keempat.Font = new System.Drawing.Font("Century Gothic", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Keempat.Location = new System.Drawing.Point(470, 50);
            this.lb_Keempat.Name = "lb_Keempat";
            this.lb_Keempat.Size = new System.Drawing.Size(65, 77);
            this.lb_Keempat.TabIndex = 61;
            this.lb_Keempat.Text = "_";
            // 
            // lb_Kelima
            // 
            this.lb_Kelima.AutoSize = true;
            this.lb_Kelima.Font = new System.Drawing.Font("Century Gothic", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Kelima.Location = new System.Drawing.Point(555, 50);
            this.lb_Kelima.Name = "lb_Kelima";
            this.lb_Kelima.Size = new System.Drawing.Size(65, 77);
            this.lb_Kelima.TabIndex = 60;
            this.lb_Kelima.Text = "_";
            // 
            // lb_Kedua
            // 
            this.lb_Kedua.AutoSize = true;
            this.lb_Kedua.Font = new System.Drawing.Font("Century Gothic", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Kedua.Location = new System.Drawing.Point(300, 50);
            this.lb_Kedua.Name = "lb_Kedua";
            this.lb_Kedua.Size = new System.Drawing.Size(65, 77);
            this.lb_Kedua.TabIndex = 59;
            this.lb_Kedua.Text = "_";
            // 
            // lb_Ketiga
            // 
            this.lb_Ketiga.AutoSize = true;
            this.lb_Ketiga.Font = new System.Drawing.Font("Century Gothic", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Ketiga.Location = new System.Drawing.Point(385, 50);
            this.lb_Ketiga.Name = "lb_Ketiga";
            this.lb_Ketiga.Size = new System.Drawing.Size(65, 77);
            this.lb_Ketiga.TabIndex = 58;
            this.lb_Ketiga.Text = "_";
            // 
            // btn_HurufM
            // 
            this.btn_HurufM.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufM.Location = new System.Drawing.Point(525, 295);
            this.btn_HurufM.Name = "btn_HurufM";
            this.btn_HurufM.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufM.TabIndex = 57;
            this.btn_HurufM.Text = "M";
            this.btn_HurufM.UseVisualStyleBackColor = true;
            this.btn_HurufM.Click += new System.EventHandler(this.btn_HurufM_Click);
            // 
            // btn_HurufN
            // 
            this.btn_HurufN.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufN.Location = new System.Drawing.Point(465, 295);
            this.btn_HurufN.Name = "btn_HurufN";
            this.btn_HurufN.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufN.TabIndex = 56;
            this.btn_HurufN.Text = "N";
            this.btn_HurufN.UseVisualStyleBackColor = true;
            this.btn_HurufN.Click += new System.EventHandler(this.btn_HurufN_Click);
            // 
            // btn_HurufB
            // 
            this.btn_HurufB.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufB.Location = new System.Drawing.Point(405, 295);
            this.btn_HurufB.Name = "btn_HurufB";
            this.btn_HurufB.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufB.TabIndex = 55;
            this.btn_HurufB.Text = "B";
            this.btn_HurufB.UseVisualStyleBackColor = true;
            this.btn_HurufB.Click += new System.EventHandler(this.btn_HurufB_Click);
            // 
            // btn_HurufV
            // 
            this.btn_HurufV.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufV.Location = new System.Drawing.Point(345, 295);
            this.btn_HurufV.Name = "btn_HurufV";
            this.btn_HurufV.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufV.TabIndex = 54;
            this.btn_HurufV.Text = "V";
            this.btn_HurufV.UseVisualStyleBackColor = true;
            this.btn_HurufV.Click += new System.EventHandler(this.btn_HurufV_Click);
            // 
            // btn_HurufC
            // 
            this.btn_HurufC.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufC.Location = new System.Drawing.Point(285, 295);
            this.btn_HurufC.Name = "btn_HurufC";
            this.btn_HurufC.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufC.TabIndex = 53;
            this.btn_HurufC.Text = "C";
            this.btn_HurufC.UseVisualStyleBackColor = true;
            this.btn_HurufC.Click += new System.EventHandler(this.btn_HurufC_Click);
            // 
            // btn_HurufX
            // 
            this.btn_HurufX.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufX.Location = new System.Drawing.Point(225, 295);
            this.btn_HurufX.Name = "btn_HurufX";
            this.btn_HurufX.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufX.TabIndex = 52;
            this.btn_HurufX.Text = "X";
            this.btn_HurufX.UseVisualStyleBackColor = true;
            this.btn_HurufX.Click += new System.EventHandler(this.btn_HurufX_Click);
            // 
            // btn_HurufZ
            // 
            this.btn_HurufZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufZ.Location = new System.Drawing.Point(165, 295);
            this.btn_HurufZ.Name = "btn_HurufZ";
            this.btn_HurufZ.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufZ.TabIndex = 51;
            this.btn_HurufZ.Text = "Z";
            this.btn_HurufZ.UseVisualStyleBackColor = true;
            this.btn_HurufZ.Click += new System.EventHandler(this.btn_HurufZ_Click);
            // 
            // btn_HurufL
            // 
            this.btn_HurufL.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufL.Location = new System.Drawing.Point(620, 235);
            this.btn_HurufL.Name = "btn_HurufL";
            this.btn_HurufL.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufL.TabIndex = 50;
            this.btn_HurufL.Text = "L";
            this.btn_HurufL.UseVisualStyleBackColor = true;
            this.btn_HurufL.Click += new System.EventHandler(this.btn_HurufL_Click);
            // 
            // btn_HurufK
            // 
            this.btn_HurufK.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufK.Location = new System.Drawing.Point(560, 235);
            this.btn_HurufK.Name = "btn_HurufK";
            this.btn_HurufK.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufK.TabIndex = 49;
            this.btn_HurufK.Text = "K";
            this.btn_HurufK.UseVisualStyleBackColor = true;
            this.btn_HurufK.Click += new System.EventHandler(this.btn_HurufK_Click);
            // 
            // btn_HurufJ
            // 
            this.btn_HurufJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufJ.Location = new System.Drawing.Point(500, 235);
            this.btn_HurufJ.Name = "btn_HurufJ";
            this.btn_HurufJ.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufJ.TabIndex = 48;
            this.btn_HurufJ.Text = "J";
            this.btn_HurufJ.UseVisualStyleBackColor = true;
            this.btn_HurufJ.Click += new System.EventHandler(this.btn_HurufJ_Click);
            // 
            // btn_HurufH
            // 
            this.btn_HurufH.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufH.Location = new System.Drawing.Point(440, 235);
            this.btn_HurufH.Name = "btn_HurufH";
            this.btn_HurufH.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufH.TabIndex = 47;
            this.btn_HurufH.Text = "H";
            this.btn_HurufH.UseVisualStyleBackColor = true;
            this.btn_HurufH.Click += new System.EventHandler(this.btn_HurufH_Click);
            // 
            // btn_HurufG
            // 
            this.btn_HurufG.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufG.Location = new System.Drawing.Point(380, 235);
            this.btn_HurufG.Name = "btn_HurufG";
            this.btn_HurufG.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufG.TabIndex = 46;
            this.btn_HurufG.Text = "G";
            this.btn_HurufG.UseVisualStyleBackColor = true;
            this.btn_HurufG.Click += new System.EventHandler(this.btn_HurufG_Click);
            // 
            // btn_HurufF
            // 
            this.btn_HurufF.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufF.Location = new System.Drawing.Point(320, 235);
            this.btn_HurufF.Name = "btn_HurufF";
            this.btn_HurufF.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufF.TabIndex = 45;
            this.btn_HurufF.Text = "F";
            this.btn_HurufF.UseVisualStyleBackColor = true;
            this.btn_HurufF.Click += new System.EventHandler(this.btn_HurufF_Click);
            // 
            // btn_HurufD
            // 
            this.btn_HurufD.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufD.Location = new System.Drawing.Point(260, 235);
            this.btn_HurufD.Name = "btn_HurufD";
            this.btn_HurufD.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufD.TabIndex = 44;
            this.btn_HurufD.Text = "D";
            this.btn_HurufD.UseVisualStyleBackColor = true;
            this.btn_HurufD.Click += new System.EventHandler(this.btn_HurufD_Click);
            // 
            // btn_HurufS
            // 
            this.btn_HurufS.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufS.Location = new System.Drawing.Point(200, 235);
            this.btn_HurufS.Name = "btn_HurufS";
            this.btn_HurufS.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufS.TabIndex = 43;
            this.btn_HurufS.Text = "S";
            this.btn_HurufS.UseVisualStyleBackColor = true;
            this.btn_HurufS.Click += new System.EventHandler(this.btn_HurufS_Click);
            // 
            // btn_HurufA
            // 
            this.btn_HurufA.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufA.Location = new System.Drawing.Point(140, 235);
            this.btn_HurufA.Name = "btn_HurufA";
            this.btn_HurufA.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufA.TabIndex = 42;
            this.btn_HurufA.Text = "A";
            this.btn_HurufA.UseVisualStyleBackColor = true;
            this.btn_HurufA.Click += new System.EventHandler(this.btn_HurufA_Click);
            // 
            // btn_HurufP
            // 
            this.btn_HurufP.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufP.Location = new System.Drawing.Point(655, 175);
            this.btn_HurufP.Name = "btn_HurufP";
            this.btn_HurufP.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufP.TabIndex = 41;
            this.btn_HurufP.Text = "P";
            this.btn_HurufP.UseVisualStyleBackColor = true;
            this.btn_HurufP.Click += new System.EventHandler(this.btn_HurufP_Click);
            // 
            // btn_HurufO
            // 
            this.btn_HurufO.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufO.Location = new System.Drawing.Point(595, 175);
            this.btn_HurufO.Name = "btn_HurufO";
            this.btn_HurufO.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufO.TabIndex = 40;
            this.btn_HurufO.Text = "O";
            this.btn_HurufO.UseVisualStyleBackColor = true;
            this.btn_HurufO.Click += new System.EventHandler(this.btn_HurufO_Click);
            // 
            // btn_HurufI
            // 
            this.btn_HurufI.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufI.Location = new System.Drawing.Point(535, 175);
            this.btn_HurufI.Name = "btn_HurufI";
            this.btn_HurufI.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufI.TabIndex = 39;
            this.btn_HurufI.Text = "I";
            this.btn_HurufI.UseVisualStyleBackColor = true;
            this.btn_HurufI.Click += new System.EventHandler(this.btn_HurufI_Click);
            // 
            // btn_HurufU
            // 
            this.btn_HurufU.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufU.Location = new System.Drawing.Point(475, 175);
            this.btn_HurufU.Name = "btn_HurufU";
            this.btn_HurufU.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufU.TabIndex = 38;
            this.btn_HurufU.Text = "U";
            this.btn_HurufU.UseVisualStyleBackColor = true;
            this.btn_HurufU.Click += new System.EventHandler(this.btn_HurufU_Click);
            // 
            // btn_HurufY
            // 
            this.btn_HurufY.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufY.Location = new System.Drawing.Point(415, 175);
            this.btn_HurufY.Name = "btn_HurufY";
            this.btn_HurufY.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufY.TabIndex = 37;
            this.btn_HurufY.Text = "Y";
            this.btn_HurufY.UseVisualStyleBackColor = true;
            this.btn_HurufY.Click += new System.EventHandler(this.btn_HurufY_Click);
            // 
            // btn_HurufT
            // 
            this.btn_HurufT.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufT.Location = new System.Drawing.Point(355, 175);
            this.btn_HurufT.Name = "btn_HurufT";
            this.btn_HurufT.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufT.TabIndex = 36;
            this.btn_HurufT.Text = "T";
            this.btn_HurufT.UseVisualStyleBackColor = true;
            this.btn_HurufT.Click += new System.EventHandler(this.btn_HurufT_Click);
            // 
            // btn_HurufR
            // 
            this.btn_HurufR.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufR.Location = new System.Drawing.Point(295, 175);
            this.btn_HurufR.Name = "btn_HurufR";
            this.btn_HurufR.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufR.TabIndex = 35;
            this.btn_HurufR.Text = "R";
            this.btn_HurufR.UseVisualStyleBackColor = true;
            this.btn_HurufR.Click += new System.EventHandler(this.btn_HurufR_Click);
            // 
            // btn_HurufE
            // 
            this.btn_HurufE.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufE.Location = new System.Drawing.Point(235, 175);
            this.btn_HurufE.Name = "btn_HurufE";
            this.btn_HurufE.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufE.TabIndex = 34;
            this.btn_HurufE.Text = "E";
            this.btn_HurufE.UseVisualStyleBackColor = true;
            this.btn_HurufE.Click += new System.EventHandler(this.btn_HurufE_Click);
            // 
            // btn_HurufW
            // 
            this.btn_HurufW.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufW.Location = new System.Drawing.Point(175, 175);
            this.btn_HurufW.Name = "btn_HurufW";
            this.btn_HurufW.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufW.TabIndex = 33;
            this.btn_HurufW.Text = "W";
            this.btn_HurufW.UseVisualStyleBackColor = true;
            this.btn_HurufW.Click += new System.EventHandler(this.btn_HurufW_Click);
            // 
            // btn_HurufQ
            // 
            this.btn_HurufQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HurufQ.Location = new System.Drawing.Point(115, 175);
            this.btn_HurufQ.Name = "btn_HurufQ";
            this.btn_HurufQ.Size = new System.Drawing.Size(50, 50);
            this.btn_HurufQ.TabIndex = 32;
            this.btn_HurufQ.Text = "Q";
            this.btn_HurufQ.UseVisualStyleBackColor = true;
            this.btn_HurufQ.Click += new System.EventHandler(this.btn_HurufQ_Click);
            // 
            // MainTebak
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb_Coba);
            this.Controls.Add(this.lb_Pertama);
            this.Controls.Add(this.lb_Keempat);
            this.Controls.Add(this.lb_Kelima);
            this.Controls.Add(this.lb_Kedua);
            this.Controls.Add(this.lb_Ketiga);
            this.Controls.Add(this.btn_HurufM);
            this.Controls.Add(this.btn_HurufN);
            this.Controls.Add(this.btn_HurufB);
            this.Controls.Add(this.btn_HurufV);
            this.Controls.Add(this.btn_HurufC);
            this.Controls.Add(this.btn_HurufX);
            this.Controls.Add(this.btn_HurufZ);
            this.Controls.Add(this.btn_HurufL);
            this.Controls.Add(this.btn_HurufK);
            this.Controls.Add(this.btn_HurufJ);
            this.Controls.Add(this.btn_HurufH);
            this.Controls.Add(this.btn_HurufG);
            this.Controls.Add(this.btn_HurufF);
            this.Controls.Add(this.btn_HurufD);
            this.Controls.Add(this.btn_HurufS);
            this.Controls.Add(this.btn_HurufA);
            this.Controls.Add(this.btn_HurufP);
            this.Controls.Add(this.btn_HurufO);
            this.Controls.Add(this.btn_HurufI);
            this.Controls.Add(this.btn_HurufU);
            this.Controls.Add(this.btn_HurufY);
            this.Controls.Add(this.btn_HurufT);
            this.Controls.Add(this.btn_HurufR);
            this.Controls.Add(this.btn_HurufE);
            this.Controls.Add(this.btn_HurufW);
            this.Controls.Add(this.btn_HurufQ);
            this.Name = "MainTebak";
            this.Text = "Main Tebak";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Coba;
        private System.Windows.Forms.Label lb_Pertama;
        private System.Windows.Forms.Label lb_Keempat;
        private System.Windows.Forms.Label lb_Kelima;
        private System.Windows.Forms.Label lb_Kedua;
        private System.Windows.Forms.Label lb_Ketiga;
        private System.Windows.Forms.Button btn_HurufM;
        private System.Windows.Forms.Button btn_HurufN;
        private System.Windows.Forms.Button btn_HurufB;
        private System.Windows.Forms.Button btn_HurufV;
        private System.Windows.Forms.Button btn_HurufC;
        private System.Windows.Forms.Button btn_HurufX;
        private System.Windows.Forms.Button btn_HurufZ;
        private System.Windows.Forms.Button btn_HurufL;
        private System.Windows.Forms.Button btn_HurufK;
        private System.Windows.Forms.Button btn_HurufJ;
        private System.Windows.Forms.Button btn_HurufH;
        private System.Windows.Forms.Button btn_HurufG;
        private System.Windows.Forms.Button btn_HurufF;
        private System.Windows.Forms.Button btn_HurufD;
        private System.Windows.Forms.Button btn_HurufS;
        private System.Windows.Forms.Button btn_HurufA;
        private System.Windows.Forms.Button btn_HurufP;
        private System.Windows.Forms.Button btn_HurufO;
        private System.Windows.Forms.Button btn_HurufI;
        private System.Windows.Forms.Button btn_HurufU;
        private System.Windows.Forms.Button btn_HurufY;
        private System.Windows.Forms.Button btn_HurufT;
        private System.Windows.Forms.Button btn_HurufR;
        private System.Windows.Forms.Button btn_HurufE;
        private System.Windows.Forms.Button btn_HurufW;
        private System.Windows.Forms.Button btn_HurufQ;
    }
}