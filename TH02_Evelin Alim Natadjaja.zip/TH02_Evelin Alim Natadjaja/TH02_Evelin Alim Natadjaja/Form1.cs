﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02_Evelin_Alim_Natadjaja
{
    public partial class InputKata : Form
    {
        public InputKata()
        {
            InitializeComponent();
        }

        private void btn_Play_Click(object sender, EventArgs e)
        {
            List<string> listKata = new List<string>() { tB_Word1.Text, tB_Word2.Text, 
                tB_Word3.Text, tB_Word4.Text, tB_Word5.Text};

            bool jumlahSalah = false;
            foreach (string kata in listKata)
            {
                if (kata.Length != 5)
                {
                    jumlahSalah = true;
                }
            }

            bool kataKembar = false;
            for (int i = 0; i < listKata.Count; i++)
            {
                for (int j = 0; j < listKata.Count; j++)
                {
                    if (i != j)
                    {
                        if (listKata[i] == listKata[j])
                        {
                            kataKembar = true;
                        }
                    }
                }
            }

            Random rnd = new Random();
            int indexRandom = rnd.Next(4);

            if (kataKembar || jumlahSalah) 
            {
                MessageBox.Show("There's still an error");
            }
            else
            {
                MessageBox.Show("Let's Play");
                this.Hide();
                MainTebak game = new MainTebak(listKata[indexRandom]);
                game.ShowDialog();
            }
        }
    }
}
