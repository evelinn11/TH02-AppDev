﻿namespace TH02_Evelin_Alim_Natadjaja
{
    partial class InputKata
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Word1 = new System.Windows.Forms.Label();
            this.tB_Word1 = new System.Windows.Forms.TextBox();
            this.tB_Word2 = new System.Windows.Forms.TextBox();
            this.lb_Word2 = new System.Windows.Forms.Label();
            this.lb_Word4 = new System.Windows.Forms.Label();
            this.tB_Word4 = new System.Windows.Forms.TextBox();
            this.tB_Word3 = new System.Windows.Forms.TextBox();
            this.lb_Word3 = new System.Windows.Forms.Label();
            this.lb_Word5 = new System.Windows.Forms.Label();
            this.tB_Word5 = new System.Windows.Forms.TextBox();
            this.btn_Play = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_Word1
            // 
            this.lb_Word1.AutoSize = true;
            this.lb_Word1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Word1.Location = new System.Drawing.Point(31, 42);
            this.lb_Word1.Name = "lb_Word1";
            this.lb_Word1.Size = new System.Drawing.Size(81, 24);
            this.lb_Word1.TabIndex = 0;
            this.lb_Word1.Text = "Word 1";
            // 
            // tB_Word1
            // 
            this.tB_Word1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tB_Word1.Location = new System.Drawing.Point(118, 41);
            this.tB_Word1.Name = "tB_Word1";
            this.tB_Word1.Size = new System.Drawing.Size(100, 31);
            this.tB_Word1.TabIndex = 1;
            // 
            // tB_Word2
            // 
            this.tB_Word2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tB_Word2.Location = new System.Drawing.Point(118, 78);
            this.tB_Word2.Name = "tB_Word2";
            this.tB_Word2.Size = new System.Drawing.Size(100, 31);
            this.tB_Word2.TabIndex = 3;
            // 
            // lb_Word2
            // 
            this.lb_Word2.AutoSize = true;
            this.lb_Word2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Word2.Location = new System.Drawing.Point(31, 79);
            this.lb_Word2.Name = "lb_Word2";
            this.lb_Word2.Size = new System.Drawing.Size(81, 24);
            this.lb_Word2.TabIndex = 4;
            this.lb_Word2.Text = "Word 2";
            // 
            // lb_Word4
            // 
            this.lb_Word4.AutoSize = true;
            this.lb_Word4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Word4.Location = new System.Drawing.Point(31, 153);
            this.lb_Word4.Name = "lb_Word4";
            this.lb_Word4.Size = new System.Drawing.Size(81, 24);
            this.lb_Word4.TabIndex = 8;
            this.lb_Word4.Text = "Word 4";
            // 
            // tB_Word4
            // 
            this.tB_Word4.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tB_Word4.Location = new System.Drawing.Point(118, 152);
            this.tB_Word4.Name = "tB_Word4";
            this.tB_Word4.Size = new System.Drawing.Size(100, 31);
            this.tB_Word4.TabIndex = 7;
            // 
            // tB_Word3
            // 
            this.tB_Word3.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tB_Word3.Location = new System.Drawing.Point(118, 115);
            this.tB_Word3.Name = "tB_Word3";
            this.tB_Word3.Size = new System.Drawing.Size(100, 31);
            this.tB_Word3.TabIndex = 6;
            // 
            // lb_Word3
            // 
            this.lb_Word3.AutoSize = true;
            this.lb_Word3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Word3.Location = new System.Drawing.Point(31, 116);
            this.lb_Word3.Name = "lb_Word3";
            this.lb_Word3.Size = new System.Drawing.Size(81, 24);
            this.lb_Word3.TabIndex = 5;
            this.lb_Word3.Text = "Word 3";
            // 
            // lb_Word5
            // 
            this.lb_Word5.AutoSize = true;
            this.lb_Word5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Word5.Location = new System.Drawing.Point(31, 190);
            this.lb_Word5.Name = "lb_Word5";
            this.lb_Word5.Size = new System.Drawing.Size(81, 24);
            this.lb_Word5.TabIndex = 10;
            this.lb_Word5.Text = "Word 5";
            // 
            // tB_Word5
            // 
            this.tB_Word5.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tB_Word5.Location = new System.Drawing.Point(118, 189);
            this.tB_Word5.Name = "tB_Word5";
            this.tB_Word5.Size = new System.Drawing.Size(100, 31);
            this.tB_Word5.TabIndex = 9;
            // 
            // btn_Play
            // 
            this.btn_Play.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Play.Location = new System.Drawing.Point(62, 254);
            this.btn_Play.Name = "btn_Play";
            this.btn_Play.Size = new System.Drawing.Size(138, 52);
            this.btn_Play.TabIndex = 11;
            this.btn_Play.Text = "PLAY!";
            this.btn_Play.UseVisualStyleBackColor = true;
            this.btn_Play.Click += new System.EventHandler(this.btn_Play_Click);
            // 
            // InputKata
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_Play);
            this.Controls.Add(this.lb_Word5);
            this.Controls.Add(this.tB_Word5);
            this.Controls.Add(this.lb_Word4);
            this.Controls.Add(this.tB_Word4);
            this.Controls.Add(this.tB_Word3);
            this.Controls.Add(this.lb_Word3);
            this.Controls.Add(this.lb_Word2);
            this.Controls.Add(this.tB_Word2);
            this.Controls.Add(this.tB_Word1);
            this.Controls.Add(this.lb_Word1);
            this.Name = "InputKata";
            this.Text = "Input Kata";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Word1;
        private System.Windows.Forms.TextBox tB_Word1;
        private System.Windows.Forms.TextBox tB_Word2;
        private System.Windows.Forms.Label lb_Word2;
        private System.Windows.Forms.Label lb_Word4;
        private System.Windows.Forms.TextBox tB_Word4;
        private System.Windows.Forms.TextBox tB_Word3;
        private System.Windows.Forms.Label lb_Word3;
        private System.Windows.Forms.Label lb_Word5;
        private System.Windows.Forms.TextBox tB_Word5;
        private System.Windows.Forms.Button btn_Play;
    }
}

